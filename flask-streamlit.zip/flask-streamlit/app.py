from io import StringIO
from flask import Flask, request, jsonify, render_template
import numpy as np
import pickle
from sklearn.ensemble import ExtraTreesClassifier

#first off intitialize the app via Flask object
app = Flask('myApp')


@app.route('/')
def home():
    return 'LAUNCH'

@app.route("/hc_page")
def hc_page():
    return f"""
    <html>
        <body>
            <h1>
            Supply Chain prediction model
            </h1>
            <p>Input your information to predict whether you will have on-time delivery!!</p>
        </body>
    </html>
    """


#deployment-
@app.route("/form")
def form():
    return render_template("form.html")

@app.route("/submit")
def make_prediction():
    user_input = request.args
    #create a one observation X_test

    X_test = np.array([  
    int(user_input['estimated_ship_days']),
    float(user_input['latitude']),
    float(user_input['longitude']),
    int(user_input['customer_id']),
    int(user_input['order_id']),
    int(user_input['order_hour']),
    float(user_input['order_item_profit_ratio']),
    float(user_input['order_item_discount_rate']),
    int(user_input['order_before_noon']),
    int(user_input['order_weekday']),
    int(user_input['order_month'])
    ]).reshape(1,-1)

    model = pickle.load(open("models/demo2.pkl", "rb"))
    pred = model.predict(X_test)
    pred = pred[0]
    return render_template('results.html', prediction=pred)

if __name__ == "__main__":
    app.run(debug=True)
